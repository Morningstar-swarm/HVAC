# Deploying to GitHub Pages

The site is static output built from source by `build.py`. A GitHub Actions
workflow rebuilds it on every push and publishes it to GitHub Pages, so you never
commit generated files and the live site always matches the source.

Live URL when done: **`https://<your-username>.github.io/best-comfort-hvac/`**

---

## 1. Create the repository

Go to <https://github.com/new> and create an empty repository:

* **Repository name:** `best-comfort-hvac`
* **Visibility:** Public *(Pages on private repos needs a paid plan)*
* Do **not** add a README, .gitignore or licence — the repo already has them.

Leave the page open; you need the URL, which looks like
`https://github.com/<your-username>/best-comfort-hvac.git`.

> **Shortcut — have the GitHub CLI (`gh`) installed?** Steps 1–3 collapse into:
>
> ```bash
> cd /home/user/rebuild
> gh repo create best-comfort-hvac --public --source=. --remote=origin --push
> gh api -X POST repos/:owner/:repo/pages -f build_type=workflow   # Pages -> GitHub Actions
> gh run rerun $(gh run list --workflow=deploy.yml --limit=1 --json databaseId -q '.[0].databaseId')
> ```
>
> The first run can come back red because Pages did not exist yet when it started —
> the last two commands create it with the Actions source and re-run the deploy
> against the same commit. (No run to re-run? `gh workflow run deploy.yml`.)

## 2. Turn on Pages (do this before the first push)

* Open the repository → **Settings** → **Pages**
* Under **Build and deployment → Source**, choose **GitHub Actions**

This is also what creates the `github-pages` environment the deploy job runs in —
if you push first, the first run will fail until you set it, and you then re-run it
from the **Actions** tab → *Deploy site to GitHub Pages* → **Run workflow**.

## 3. Push this project to it

From a terminal, in this folder:

```bash
cd /home/user/rebuild

git remote add origin https://github.com/<your-username>/best-comfort-hvac.git
git push -u origin main
```

Git will ask you to authenticate. The simplest way is the **GitHub CLI**
(`gh auth login`) or a **personal access token** used as the password —
GitHub no longer accepts your account password for pushes. If you have 2FA on,
create a token at <https://github.com/settings/tokens> with the `repo` scope and
paste it when asked for a password.

> **No terminal?** Use the browser instead: unzip `best-comfort-hvac.zip`, then on
> the empty repo page click *uploading an existing file* and drag the **contents**
> of the unzipped folder in (including the `.github` folder — if your file manager
> hides dotfiles, enable hidden files, or the workflow will not be uploaded).
> Commit that, and skip to step 3.

The only Pages settings that matter are the source above; the workflow requests
the permissions it needs on its own.

> The first commit is authored as *Best Comfort HVAC &lt;noreply@github.com&gt;*. To
> put your own name on it before pushing:
> `git commit --amend --reset-author --no-edit`

## 4. Watch the first deploy

* Open the **Actions** tab → *Deploy site to GitHub Pages* runs automatically after
  the push (about 30 seconds; it rebuilds and runs the QA gate).
* Green tick → open `https://<your-username>.github.io/best-comfort-hvac/`
* The deploy job prints the live URL as well.

---

## Updating the site afterwards

```bash
cd /home/user/rebuild
# 1. edit pages/*.body.html, assets/css/styles.css, assets/js/main.js, assets/images/*
python3 build.py      # optional: rebuild + QA locally first
git add -A
git commit -m "Update services page"
git push
```

The push triggers the same workflow; the site is live in under a minute. Nothing
inside `site/` is ever committed — it is regenerated on every deploy.

## How the subpath is handled

A Pages *project* site is served from `/<repo>/`, not from a domain root. The
workflow passes that automatically:

| what | value in CI |
|---|---|
| `BASE_PATH` | `/<repo>` — roots the links in `404.html` |
| `SITE_URL` | `https://<owner>.github.io/<repo>` — canonical, `og:url`, JSON-LD, `robots.txt`, `sitemap.xml` |

Every ordinary page uses relative links, so it works at any depth without
rewriting. Rename the repo or fork it and the next build adapts on its own.

## Preview the deployed shape locally

```bash
npm run preview:pages        # -> http://localhost:8130/best-comfort-hvac/
```

This builds with the subpath and serves it with GitHub Pages' rules — including
its custom-404 behaviour, so `/some/missing/page` returns the styled 404 page from
the site root. If it works here, it works on Pages.

## Notes specific to GitHub Pages

* **`_headers`, `_redirects` and `.htaccess` are inert here.** They are for
  Netlify/Cloudflare/Apache. Pages does not read them, so the CSP and long-lived
  asset caching they define are *not* applied on Pages. The custom 404, by
  contrast, needs no configuration — Pages serves `404.html` from the site root
  automatically.
* **`robots.txt` and `sitemap.xml`** point at the github.io URL for a Pages build.
  If you later put the site on a real domain, push with `SITE_URL` set — or edit
  the two env values in `.github/workflows/deploy.yml` — and rebuild.
* **A free Pages site is public**, and its URL is indexed by search engines. Add
  `<meta name="robots" content="noindex">` to `partials/header.html` if you want
  the preview hidden while you work on it.
* **Custom domain later?** Settings → Pages → *Custom domain* (this writes a
  `CNAME` file into the deployed output), then set `SITE_URL` in the workflow to
  the domain so canonical URLs match.

## If a deploy fails

| symptom | cause / fix |
|---|---|
| Pages step: "Get Pages site failed" / "Not Found" | Pages source is not set to **GitHub Actions**. Set it (step 2), then Actions → *Run workflow*. |
| Build step fails with `QA FAILED` | the gate caught a broken link, missing anchor, duplicate title, extra/missing `<h1>` or an image without `alt`. The log lists the exact page and element. |
| "Workflow does not exist" on the Actions tab | the `.github/` folder was not uploaded (see the browser-upload note in step 2). |
| Site loads but is unstyled | you are looking at a branch-deploy of the source instead of the built output — set the source back to **GitHub Actions**. |
| 404s on every page except the home page | the repo was set to *Deploy from a branch* with the output at the root; the built site includes `404.html`, so leave the source on **GitHub Actions**. |
